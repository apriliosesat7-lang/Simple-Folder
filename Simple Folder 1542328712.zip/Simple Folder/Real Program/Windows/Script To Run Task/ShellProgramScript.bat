```???
@echo off

:: Run As Administrator
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

title Script To Run Task
color C

set PASS1=...
set PASS2=...
set PASS3=...

echo ==========================
echo      Access Required
echo ==========================
echo.

set /p P1=Enter A Password:
if not "%P1%"=="%PASS1%" goto fail

set /p P2=Verified Password:
if not "%P2%"=="%PASS2%" goto fail

set /p P3=Confirm Your Password:
if not "%P3%"=="%PASS3%" goto fail

echo.
echo Entered!
echo Press Enter In Your Keyboard.
echo.
timeout /t 10 >nul

:Loop
echo %random%%random%%random%%random%%random%
goto Loop

:fail
echo.
echo Wrong Password!

for /l %%i in (4,-1,1) do (
    echo Window will close in %%i...
    timeout /t 1 >nul
)

exit
```
