
@echo off

:: Check Administrator
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

color C
title Power Manager [Selection]

set PASS=Simple

echo ==========================
echo      Power Selection
echo ==========================
echo.
echo 1.Matikan Komputer
echo 2.Mulai Ulang
echo 3.Menu BIOS
echo 4.Pengaturan Startup
echo 5.Mode Pemulihan
echo 6.Pemulihan Sistem
echo.
echo Ingin Mereset PC Ini? Lihat File Readme Di Folder.
echo.

set /p CHOICE=Pilih Opsi:
set /p INPUT=Verifikasi Kata Sandi:

if /i not "%INPUT%"=="%PASS%" goto fail

if /i "%CHOICE%"=="Matikan Komputer" shutdown /s /t 0
if /i "%CHOICE%"=="Mulai Ulang" shutdown /r /t 0
if /i "%CHOICE%"=="BIOS" shutdown /r /fw /t 0
if /i "%CHOICE%"=="Pengaturan Startup" shutdown /r /o /t 0
if /i "%CHOICE%"=="Mode Pemulihan" shutdown /r /o /t 0

if /i "%CHOICE%"=="Pemulihan Sistem" (
    start "" rstrui.exe
    exit
)

echo.
echo Opsi Salah!
pause
exit

:fail
echo.
echo Kata Sandi Salah!

for /l %%i in (4,-1,1) do (
    echo Jendela Akan Ditutup Dalam %%i...
    timeout /t 1 >nul
)

exit
```
