
@echo off

:: Check Administrator
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

color C
title Power Manager [Selection]

set PASS=Simple

echo ==========================
echo      Power Selection
echo ==========================
echo.
echo 1.Shutdown
echo 2.Restart
echo 3.BIOS
echo 4.Startup
echo 5.Recovery
echo 6.System Restore
echo.
echo You Wanna Reset This PC? Check The Readme In Folder.
echo.

set /p CHOICE=Select A Option:
set /p INPUT=Verified Password:

if /i not "%INPUT%"=="%PASS%" goto fail

if /i "%CHOICE%"=="Shutdown" shutdown /s /t 0
if /i "%CHOICE%"=="Restart" shutdown /r /t 0
if /i "%CHOICE%"=="BIOS" shutdown /r /fw /t 0
if /i "%CHOICE%"=="Startup" shutdown /r /o /t 0
if /i "%CHOICE%"=="Recovery" shutdown /r /o /t 0

if /i "%CHOICE%"=="System Restore" (
    start "" rstrui.exe
    exit
)

echo.
echo Invalid Option!
pause
exit

:fail
echo.
echo Wrong Password!

for /l %%i in (4,-1,1) do (
    echo Window will close in %%i...
    timeout /t 1 >nul
)

exit
```
