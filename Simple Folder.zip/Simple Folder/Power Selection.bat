
@echo off
color C
title Power Manager [selection]

set PASS=AdalahPokoknya

echo ==========================
echo      Power Selection
echo ==========================
echo.
echo 1. Shutdown
echo 2. Restart
echo Select Option This.
echo.

set /p CHOICE=Select Option: 

set /p INPUT=Verified Password: 

if not "%INPUT%"=="%PASS%" goto fail

if "%CHOICE%"=="1" shutdown /s /t 0
if "%CHOICE%"=="2" shutdown /r /t 0

echo Invalid Option.
pause
exit

:fail
echo.
echo Wrong Password!

for /l %%i in (4,-1,1) do (
    echo Window will close in %%i...
    timeout /t 1 >nul
)

exit
```
