```bat
@echo off
color C
title Power Manager [Selection]

set PASS=AdalahPokoknya

echo ==========================
echo      Power Selection
echo ==========================
echo.
echo 1. Shutdown
echo 2. Restart
echo 3. BIOS / UEFI Settings
echo 4. Startup Settings
echo You Wanna Reset This PC? Check The Readme In Folder
echo.

set /p CHOICE=Select Option:
set /p INPUT=Verified Password:

if not "%INPUT%"=="%PASS%" goto fail

if "%CHOICE%"=="1" shutdown /s /t 0
if "%CHOICE%"=="2" shutdown /r /t 0

REM Reboot to BIOS/UEFI Firmware Settings
if "%CHOICE%"=="3" shutdown /r /fw /t 0

REM Reboot to Advanced Startup
if "%CHOICE%"=="4" shutdown /r /o /t 0

echo.
echo Invalid Option!
pause
exit

:fail
echo.
echo Wrong Password!

for /l %%i in (4,-1,1) do (
    echo Window will close in %%i...
    timeout /t 1 >nul
)

exit
```
